export const rooms = {
  bedroom: {
    name: 'Bedroom',
    connections: ['hallway1'],
    ambient: '#232323',
    furniture: [
      { type: 'bed', x: 0.25, y: 0.25, w: 0.25, h: 0.15 },
      { type: 'dresser', x: 0.7, y: 0.2, w: 0.1, h: 0.2 },
      { type: 'trapdoor', x: 0.1, y: 0.8, w: 0.08, h: 0.08, leadsTo: 'secretPassage' }
    ]
  },
  hallway1: {
    name: 'Main Hallway',
    connections: ['bedroom', 'kitchen', 'bathroom', 'hallway2', 'study'],
    ambient: '#1a1a1a',
    furniture: [
      { type: 'plant', x: 0.1, y: 0.3, w: 0.05, h: 0.1 },
      { type: 'painting', x: 0.4, y: 0.1, w: 0.15, h: 0.08 }
    ]
  },
  hallway2: {
    name: 'East Hallway',
    connections: ['hallway1', 'library', 'guestRoom', 'atticStairs'],
    ambient: '#1a1a1a',
    furniture: [
      { type: 'bookshelf', x: 0.15, y: 0.1, w: 0.1, h: 0.3 },
      { type: 'chair', x: 0.8, y: 0.4, w: 0.08, h: 0.08 }
    ]
  },
  kitchen: {
    name: 'Kitchen',
    connections: ['hallway1', 'pantry', 'diningRoom'],
    ambient: '#202020',
    furniture: [
      { type: 'counter', x: 0.2, y: 0.2, w: 0.4, h: 0.1 },
      { type: 'fridge', x: 0.7, y: 0.15, w: 0.1, h: 0.25 },
      { type: 'island', x: 0.35, y: 0.5, w: 0.2, h: 0.15 },
      { type: 'trapdoor', x: 0.8, y: 0.8, w: 0.08, h: 0.08, leadsTo: 'winecellar' }
    ]
  },
  bathroom: {
    name: 'Bathroom',
    connections: ['hallway1'],
    ambient: '#1c1c1c',
    furniture: [
      { type: 'sink', x: 0.3, y: 0.2, w: 0.15, h: 0.1 },
      { type: 'shower', x: 0.6, y: 0.15, w: 0.15, h: 0.2 },
      { type: 'mirror', x: 0.3, y: 0.05, w: 0.15, h: 0.1, isSecret: true, leadsTo: 'hiddenRoom' }
    ]
  },
  study: {
    name: 'Study',
    connections: ['hallway1', 'secretRoom'],
    ambient: '#1e1e1e',
    furniture: [
      { type: 'desk', x: 0.3, y: 0.3, w: 0.25, h: 0.12 },
      { type: 'bookshelf', x: 0.1, y: 0.1, w: 0.1, h: 0.4 },
      { type: 'chair', x: 0.35, y: 0.45, w: 0.08, h: 0.08 }
    ]
  },
  library: {
    name: 'Library',
    connections: ['hallway2'],
    ambient: '#1d1d1d',
    furniture: [
      { type: 'bookshelf', x: 0.1, y: 0.1, w: 0.8, h: 0.15 },
      { type: 'readingTable', x: 0.3, y: 0.4, w: 0.4, h: 0.15 },
      { type: 'secretLever', x: 0.85, y: 0.12, w: 0.05, h: 0.1, reveals: 'secretPassage' }
    ]
  },
  guestRoom: {
    name: 'Guest Room',
    connections: ['hallway2'],
    ambient: '#212121',
    furniture: [
      { type: 'bed', x: 0.2, y: 0.2, w: 0.3, h: 0.15 },
      { type: 'wardrobe', x: 0.7, y: 0.1, w: 0.15, h: 0.3 }
    ]
  },
  atticStairs: {
    name: 'Attic Stairs',
    connections: ['hallway2', 'attic'],
    ambient: '#151515',
    furniture: [
      { type: 'oldChest', x: 0.2, y: 0.6, w: 0.15, h: 0.15 },
      { type: 'brokenChair', x: 0.6, y: 0.7, w: 0.1, h: 0.1 }
    ]
  },
  attic: {
    name: 'Attic',
    connections: ['atticStairs'],
    ambient: '#111111',
    furniture: [
      { type: 'boxes', x: 0.1, y: 0.2, w: 0.2, h: 0.2 },
      { type: 'oldFurniture', x: 0.4, y: 0.3, w: 0.3, h: 0.2 },
      { type: 'trapdoor', x: 0.8, y: 0.1, w: 0.08, h: 0.08, leadsTo: 'secretRoom' }
    ]
  },
  diningRoom: {
    name: 'Dining Room',
    connections: ['kitchen'],
    ambient: '#1f1f1f',
    furniture: [
      { type: 'diningTable', x: 0.2, y: 0.3, w: 0.6, h: 0.2 },
      { type: 'chandelier', x: 0.5, y: 0.1, w: 0.2, h: 0.1 }
    ]
  },
  secretRoom: {
    name: 'Secret Room',
    connections: ['study', 'attic'],
    ambient: '#0f0f0f',
    furniture: [
      { type: 'mysteriousAltar', x: 0.4, y: 0.4, w: 0.2, h: 0.2 },
      { type: 'ancientSymbols', x: 0.1, y: 0.1, w: 0.8, h: 0.1 }
    ]
  },
  secretPassage: {
    name: 'Secret Passage',
    connections: ['bedroom', 'library'],
    ambient: '#080808',
    furniture: [
      { type: 'torch', x: 0.2, y: 0.3, w: 0.05, h: 0.1 },
      { type: 'cobwebs', x: 0.5, y: 0.1, w: 0.3, h: 0.2 }
    ]
  },
  winecellar: {
    name: 'Wine Cellar',
    connections: ['kitchen'],
    ambient: '#0a0a0a',
    furniture: [
      { type: 'wineRacks', x: 0.1, y: 0.1, w: 0.8, h: 0.2 },
      { type: 'barrels', x: 0.2, y: 0.4, w: 0.4, h: 0.3 }
    ]
  },
  hiddenRoom: {
    name: 'Hidden Room',
    connections: ['bathroom'],
    ambient: '#050505',
    furniture: [
      { type: 'strangeDevice', x: 0.4, y: 0.3, w: 0.2, h: 0.2 },
      { type: 'mysteriousNotes', x: 0.7, y: 0.2, w: 0.1, h: 0.1 }
    ]
  }
};