import { gameState } from './game/state.js';
import { audioManager } from './game/audio.js';
import { render } from './game/renderer/index.js';
import { InputManager } from './game/input.js';
import { kellanAI } from './game/kellan.js';
import { LoadingScreen } from './game/loadingScreen.js';

class Game {
  constructor() {
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.inputManager = new InputManager(this.canvas);
    this.loadingScreen = new LoadingScreen(this.canvas, this.ctx);
    this.boundGameLoop = this.gameLoop.bind(this);
    this.boundResizeCanvas = this.resizeCanvas.bind(this);
    this.lastTimeUpdate = Date.now();
    this.gameStarted = false;
  }

  init() {
    this.resizeCanvas();
    window.addEventListener('resize', this.boundResizeCanvas);
    
    // Hide the default loading text
    const loadingElement = document.getElementById('loading');
    if (loadingElement) {
      loadingElement.style.display = 'none';
    }
    
    // Start with loading screen
    this.loadingLoop();
  }

  loadingLoop() {
    this.loadingScreen.update();
    this.loadingScreen.render();

    if (this.loadingScreen.isComplete) {
      this.startGame();
    } else {
      requestAnimationFrame(() => this.loadingLoop());
    }
  }

  startGame() {
    this.gameStarted = true;
    this.inputManager.init();
    this.gameLoop();
  }

  resizeCanvas() {
    this.canvas.width = window.innerWidth - 40;
    this.canvas.height = window.innerHeight - 40;
    gameState.playerPosition.x = this.canvas.width / 2;
    gameState.playerPosition.y = this.canvas.height / 2;
  }

  updateTime() {
    const now = Date.now();
    if (now - this.lastTimeUpdate >= 1000) {
      gameState.time = (gameState.time + 1) % 360;
      this.lastTimeUpdate = now;
    }
  }

  gameLoop() {
    this.updateTime();
    kellanAI.update();
    render(this.ctx, this.canvas);
    requestAnimationFrame(this.boundGameLoop);
  }

  cleanup() {
    this.inputManager.cleanup();
    window.removeEventListener('resize', this.boundResizeCanvas);
    audioManager.stopAll();
  }
}

// Start the game
const game = new Game();
game.init();