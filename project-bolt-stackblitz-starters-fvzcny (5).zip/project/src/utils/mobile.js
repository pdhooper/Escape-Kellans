export function isMobileDevice() {
  return (
    typeof window.orientation !== "undefined" ||
    navigator.userAgent.indexOf("IEMobile") !== -1 ||
    /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
  );
}

export function getDevicePixelRatio() {
  return window.devicePixelRatio || 1;
}