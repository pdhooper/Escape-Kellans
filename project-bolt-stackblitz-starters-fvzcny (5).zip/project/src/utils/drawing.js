export function drawStickFigure(ctx, x, y, color, scale = 1, angle = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.scale(scale, scale);
  
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  
  // Head
  ctx.beginPath();
  ctx.arc(0, -10, 8, 0, Math.PI * 2);
  ctx.stroke();
  
  // Body
  ctx.beginPath();
  ctx.moveTo(0, -2);
  ctx.lineTo(0, 15);
  ctx.stroke();
  
  // Arms
  ctx.beginPath();
  ctx.moveTo(-12, 5);
  ctx.lineTo(12, 5);
  ctx.stroke();
  
  // Legs
  ctx.beginPath();
  ctx.moveTo(0, 15);
  ctx.lineTo(-8, 30);
  ctx.moveTo(0, 15);
  ctx.lineTo(8, 30);
  ctx.stroke();
  
  ctx.restore();
}

export function createLightingEffect(ctx, x, y, radius) {
  const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
  gradient.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
  gradient.addColorStop(0.2, 'rgba(255, 255, 200, 0.2)');
  gradient.addColorStop(0.7, 'rgba(255, 200, 150, 0.1)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0.95)');
  return gradient;
}

export function drawText(ctx, text, x, y, fontSize, color, shadowColor = 'rgba(0, 0, 0, 0.5)') {
  ctx.font = `bold ${fontSize} "Creepster", Arial`;
  ctx.textAlign = 'center';
  
  // Draw shadow
  ctx.fillStyle = shadowColor;
  ctx.fillText(text, x + 2, y + 2);
  
  // Draw main text
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

export function drawMessage(ctx, canvas) {
  if (!gameState.message) return;
  
  const padding = 20;
  const y = canvas.height - 100;
  
  ctx.save();
  // Message background
  ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
  ctx.fillRect(0, y - padding, canvas.width, 60);
  
  // Message text
  ctx.font = '24px Arial';
  ctx.fillStyle = '#fff';
  ctx.textAlign = 'center';
  ctx.fillText(gameState.message, canvas.width / 2, y + 20);
  ctx.restore();
}

export function drawKeypad(ctx, canvas) {
  if (!gameState.showKeypad) return;
  
  const width = 300;
  const height = 400;
  const x = (canvas.width - width) / 2;
  const y = (canvas.height - height) / 2;
  
  ctx.save();
  // Keypad background
  ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
  ctx.fillRect(x, y, width, height);
  
  // Display
  ctx.fillStyle = '#222';
  ctx.fillRect(x + 20, y + 20, width - 40, 60);
  ctx.fillStyle = '#0f0';
  ctx.font = '32px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(gameState.keypadInput + '_', x + width - 40, y + 60);
  
  // Buttons
  const buttons = [
    '1', '2', '3',
    '4', '5', '6',
    '7', '8', '9',
    'CLR', '0', 'ENT'
  ];
  
  buttons.forEach((btn, i) => {
    const btnX = x + 20 + (i % 3) * 90;
    const btnY = y + 100 + Math.floor(i / 3) * 70;
    
    ctx.fillStyle = '#444';
    ctx.fillRect(btnX, btnY, 80, 60);
    
    ctx.fillStyle = '#fff';
    ctx.font = '24px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(btn, btnX + 40, btnY + 35);
  });
  
  ctx.restore();
}