export const puzzles = {
  basementLock: {
    id: 'basementLock',
    room: 'hallway',
    locksRoom: 'basement',
    x: 0.8,
    y: 0.7,
    hint: 'The basement door has a keypad. Look for numbers in the study.',
    clue: 'There are scratches around certain books: 1, 9, 8, 4',
    solution: '1984',
    successMessage: 'The basement door unlocks with a click!'
  },
  safeCode: {
    id: 'safeCode',
    room: 'study',
    x: 0.3,
    y: 0.2,
    hint: 'The safe seems to require a word rather than numbers.',
    clue: 'A torn note reads: "What\'s black and white and red all over? - K"',
    solution: 'newspaper',
    successMessage: 'The safe opens, revealing a key!'
  },
  pantryPuzzle: {
    id: 'pantryPuzzle',
    room: 'kitchen',
    locksRoom: 'pantry',
    x: 0.9,
    y: 0.4,
    hint: 'The pantry door has colored symbols.',
    clue: 'Recipe note: "Always remember: Blue, Red, Red, Green"',
    solution: 'BRRG',
    successMessage: 'The pantry door mechanism whirs to life!'
  }
};