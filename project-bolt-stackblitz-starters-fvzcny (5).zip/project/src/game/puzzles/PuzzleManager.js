import { gameState } from '../state.js';
import { puzzles } from './puzzleData.js';
import { audioManager } from '../audio.js';

export class PuzzleManager {
  constructor() {
    this.activePuzzles = new Map();
    this.solvedPuzzles = new Set();
    this.cluesFound = new Set();
  }

  initializePuzzles() {
    Object.entries(puzzles).forEach(([id, puzzle]) => {
      if (!this.solvedPuzzles.has(id)) {
        this.activePuzzles.set(id, { ...puzzle, found: false });
      }
    });
  }

  checkForClues(playerPosition, currentRoom) {
    const roomPuzzles = Array.from(this.activePuzzles.values())
      .filter(puzzle => puzzle.room === currentRoom);

    roomPuzzles.forEach(puzzle => {
      const distance = Math.hypot(
        playerPosition.x - (puzzle.x * window.innerWidth),
        playerPosition.y - (puzzle.y * window.innerHeight)
      );

      if (distance < 50 && !this.cluesFound.has(puzzle.id)) {
        this.cluesFound.add(puzzle.id);
        gameState.message = `Found clue: ${puzzle.clue}`;
        audioManager.play('clueFound');
        setTimeout(() => {
          if (gameState.message === `Found clue: ${puzzle.clue}`) {
            gameState.message = '';
          }
        }, 3000);
      }
    });
  }

  tryUnlock(code, room) {
    const puzzle = Array.from(this.activePuzzles.values())
      .find(p => p.room === room && p.solution === code);

    if (puzzle && !this.solvedPuzzles.has(puzzle.id)) {
      this.solvedPuzzles.add(puzzle.id);
      this.activePuzzles.delete(puzzle.id);
      audioManager.play('puzzleSolved');
      gameState.message = puzzle.successMessage;
      setTimeout(() => {
        if (gameState.message === puzzle.successMessage) {
          gameState.message = '';
        }
      }, 3000);
      return true;
    }
    return false;
  }

  getPuzzleHints(room) {
    return Array.from(this.activePuzzles.values())
      .filter(puzzle => puzzle.room === room)
      .map(puzzle => puzzle.hint);
  }

  isRoomLocked(room) {
    return Array.from(this.activePuzzles.values())
      .some(puzzle => puzzle.locksRoom === room && !this.solvedPuzzles.has(puzzle.id));
  }
}