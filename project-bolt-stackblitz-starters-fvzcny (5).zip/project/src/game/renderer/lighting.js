import { gameState } from '../state.js';
import { createLightingEffect } from '../../utils/drawing.js';

export function applyLighting(ctx, canvas) {
  if (!gameState.lights) {
    // Dark overlay
    ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Flashlight
    const gradient = createLightingEffect(
      ctx,
      gameState.playerPosition.x,
      gameState.playerPosition.y,
      200
    );
    
    ctx.save();
    ctx.beginPath();
    ctx.translate(gameState.playerPosition.x, gameState.playerPosition.y);
    ctx.rotate(gameState.flashlightAngle);
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, 200, -Math.PI/4, Math.PI/4);
    ctx.lineTo(0, 0);
    ctx.fillStyle = gradient;
    ctx.fill();
    ctx.restore();
  }
}

export function addVignette(ctx, canvas) {
  const gradient = ctx.createRadialGradient(
    canvas.width / 2, canvas.height / 2, 0,
    canvas.width / 2, canvas.height / 2, canvas.width / 1.5
  );
  gradient.addColorStop(0, 'rgba(0,0,0,0)');
  gradient.addColorStop(0.5, `rgba(0,0,0,${gameState.vignette * 0.3})`);
  gradient.addColorStop(1, `rgba(0,0,0,${0.7 + gameState.vignette * 0.3})`);
  
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}