import { rooms } from '../../config/rooms.js';
import { gameState } from '../state.js';

export function drawRoom(ctx, canvas) {
  const room = rooms[gameState.currentRoom];
  ctx.fillStyle = room.ambient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Draw room name
  ctx.fillStyle = '#ffffff';
  ctx.font = '24px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(room.name, 20, 40);
  
  // Draw available exits
  const connections = room.connections;
  ctx.font = '16px Arial';
  ctx.fillStyle = '#888888';
  ctx.fillText('Exits: ' + connections.join(', '), 20, 70);
}

export function drawFurniture(ctx, canvas) {
  const furniture = rooms[gameState.currentRoom].furniture;
  furniture.forEach(item => {
    const x = item.x * canvas.width;
    const y = item.y * canvas.height;
    const w = item.w * canvas.width;
    const h = item.h * canvas.height;
    
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 5;
    
    // Special rendering for trap doors and secret furniture
    if (item.type === 'trapdoor' || item.isSecret) {
      ctx.fillStyle = gameState.lights ? '#4a3728' : '#2a2a2a';
      if (isPlayerNear(item, canvas)) {
        ctx.fillStyle = gameState.lights ? '#6a5748' : '#3a3a3a';
        
        // Show interaction hint
        ctx.fillStyle = '#ffffff';
        ctx.font = '14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Press E to use', x + w/2, y - 10);
      }
    } else {
      ctx.fillStyle = gameState.lights ? '#8b4513' : '#444';
    }
    
    ctx.fillRect(x, y, w, h);
    
    ctx.strokeStyle = gameState.lights ? '#654321' : '#333';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
    
    ctx.restore();
  });
}

function isPlayerNear(item, canvas) {
  const itemX = item.x * canvas.width;
  const itemY = item.y * canvas.height;
  const distance = Math.hypot(
    itemX - gameState.playerPosition.x,
    itemY - gameState.playerPosition.y
  );
  return distance < 50;
}