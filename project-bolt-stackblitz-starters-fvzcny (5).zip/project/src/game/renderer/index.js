import { gameState } from '../state.js';
import { renderDifficultySelect } from './difficultySelect.js';
import { drawRoom, drawFurniture } from './room.js';
import { applyLighting, addVignette } from './lighting.js';
import { drawHUD, drawGameOver } from './hud.js';
import { drawPlayer, drawKellan } from './characters.js';
import { drawMobileControls } from './mobileControls.js';

function applyScreenShake(ctx) {
  if (gameState.shake > 0) {
    const shakeX = (Math.random() - 0.5) * gameState.shake;
    const shakeY = (Math.random() - 0.5) * gameState.shake;
    ctx.translate(shakeX, shakeY);
    gameState.shake *= 0.9;
  }
}

export function render(ctx, canvas) {
  ctx.save();
  
  if (gameState.showDifficultySelect) {
    renderDifficultySelect(ctx, canvas);
  } else {
    applyScreenShake(ctx);
    drawRoom(ctx, canvas);
    drawFurniture(ctx, canvas);
    applyLighting(ctx, canvas);
    drawPlayer(ctx);
    drawKellan(ctx);
    addVignette(ctx, canvas);
    drawHUD(ctx, canvas);
    drawMobileControls(ctx, canvas);
    
    if (gameState.isGameOver) {
      drawGameOver(ctx, canvas);
    }
  }
  
  ctx.restore();
}