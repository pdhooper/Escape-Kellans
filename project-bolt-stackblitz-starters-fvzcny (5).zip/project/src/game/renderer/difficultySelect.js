import { gameState } from '../state.js';
import { drawText } from '../../utils/drawing.js';
import { DIFFICULTY_LEVELS } from '../difficultyManager.js';

export function renderDifficultySelect(ctx, canvas) {
  // Background
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Title
  drawText(
    ctx,
    'SELECT DIFFICULTY',
    canvas.width / 2,
    canvas.height / 4,
    '48px',
    '#ff0000'
  );
  
  // Difficulty buttons
  const difficulties = [
    { name: 'EASY', value: DIFFICULTY_LEVELS.EASY },
    { name: 'MEDIUM', value: DIFFICULTY_LEVELS.MEDIUM },
    { name: 'HARD', value: DIFFICULTY_LEVELS.HARD }
  ];
  
  difficulties.forEach((diff, index) => {
    const y = canvas.height / 2 + index * 80;
    const isSelected = gameState.difficulty === diff.value;
    
    // Draw button background
    ctx.fillStyle = isSelected ? 'rgba(255, 0, 0, 0.3)' : 'rgba(255, 255, 255, 0.1)';
    ctx.beginPath();
    ctx.roundRect(canvas.width / 2 - 100, y - 30, 200, 60, 10);
    ctx.fill();
    
    // Draw button text
    ctx.fillStyle = isSelected ? '#ff0000' : '#ffffff';
    ctx.font = `${isSelected ? 'bold ' : ''}32px "Creepster", Arial`;
    ctx.textAlign = 'center';
    ctx.fillText(diff.name, canvas.width / 2, y + 10);
  });
  
  // Instructions
  ctx.fillStyle = '#888';
  ctx.font = '24px Arial';
  ctx.fillText(
    'ontouchstart' in window ? 'Tap to select difficulty' : 'Use arrow keys to select, ENTER to start',
    canvas.width / 2,
    canvas.height - 100
  );
}