import { gameState } from '../state.js';
import { drawStickFigure } from '../../utils/drawing.js';
import { kellanAI } from '../kellan.js';

export function drawPlayer(ctx) {
  drawStickFigure(
    ctx,
    gameState.playerPosition.x,
    gameState.playerPosition.y,
    gameState.lights ? '#000' : '#fff',
    1,
    gameState.flashlightAngle
  );
}

export function drawKellan(ctx) {
  if (gameState.currentRoom === gameState.kellanPosition) {
    if (gameState.lights || isInFlashlightBeam(kellanAI.position)) {
      drawStickFigure(
        ctx,
        kellanAI.position.x,
        kellanAI.position.y,
        '#ff0000',
        1.2,
        Math.atan2(
          gameState.playerPosition.y - kellanAI.position.y,
          gameState.playerPosition.x - kellanAI.position.x
        )
      );
      
      const distance = Math.hypot(
        kellanAI.position.x - gameState.playerPosition.x,
        kellanAI.position.y - gameState.playerPosition.y
      );
      
      if (distance < 200) {
        gameState.shake = Math.max(gameState.shake, (200 - distance) / 10);
        gameState.vignette = Math.min(1, (200 - distance) / 200);
      }
    }
  }
}

function isInFlashlightBeam(position) {
  const dx = position.x - gameState.playerPosition.x;
  const dy = position.y - gameState.playerPosition.y;
  const angle = Math.atan2(dy, dx);
  const angleDiff = Math.abs(angle - gameState.flashlightAngle);
  return angleDiff < Math.PI / 4;
}