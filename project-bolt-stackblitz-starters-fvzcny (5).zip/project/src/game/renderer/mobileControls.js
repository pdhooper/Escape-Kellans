export function drawMobileControls(ctx, canvas) {
  if (!('ontouchstart' in window)) return;
  
  // Virtual joystick base
  ctx.save();
  ctx.globalAlpha = 0.3;
  ctx.beginPath();
  ctx.arc(100, canvas.height - 100, 50, 0, Math.PI * 2);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // Light toggle button
  ctx.beginPath();
  ctx.arc(canvas.width - 80, canvas.height - 80, 30, 0, Math.PI * 2);
  ctx.fillStyle = gameState.lights ? '#ffff00' : '#444';
  ctx.fill();
  ctx.stroke();
  
  ctx.restore();
}