import { rooms } from '../config/rooms.js';
import { gameState } from './state.js';
import { drawStickFigure, createLightingEffect, drawText, drawMessage, drawKeypad } from '../utils/drawing.js';
import { kellanAI } from './kellan.js';
import { DIFFICULTY_LEVELS } from './difficultyManager.js';

// ... [Previous render functions remain the same until drawHUD] ...

function drawHUD(ctx, canvas) {
  // Power meter
  const powerGradient = ctx.createLinearGradient(20, canvas.height - 40, 220, canvas.height - 40);
  powerGradient.addColorStop(0, '#ff0000');
  powerGradient.addColorStop(0.5, '#ffff00');
  powerGradient.addColorStop(1, '#00ff00');
  
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fillRect(10, canvas.height - 60, 220, 50);
  
  ctx.fillStyle = powerGradient;
  ctx.fillRect(20, canvas.height - 40, gameState.power * 2, 20);
  
  // Time display
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fillRect(canvas.width - 150, 10, 140, 40);
  
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'left';
  ctx.shadowColor = '#000';
  ctx.shadowBlur = 5;
  const hour = Math.floor(gameState.time / 60) % 6 + 12;
  const minute = gameState.time % 60;
  ctx.fillText(
    `${hour}:${minute.toString().padStart(2, '0')} ${hour < 12 ? 'PM' : 'AM'}`,
    canvas.width - 140,
    40
  );
  
  // Draw inventory
  if (gameState.inventory.size > 0) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(10, 10, 200, 40);
    ctx.fillStyle = '#fff';
    ctx.font = '20px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('Items: ' + Array.from(gameState.inventory).join(', '), 20, 35);
  }
  
  // Draw messages and keypad
  drawMessage(ctx, canvas);
  drawKeypad(ctx, canvas);
}