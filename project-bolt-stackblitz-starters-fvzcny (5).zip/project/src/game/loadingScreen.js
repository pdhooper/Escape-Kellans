import { drawText } from '../utils/drawing.js';

export class LoadingScreen {
  constructor(canvas, ctx) {
    this.canvas = canvas;
    this.ctx = ctx;
    this.alpha = 0;
    this.fadeIn = true;
    this.isComplete = false;
  }

  update() {
    if (this.fadeIn) {
      this.alpha = Math.min(1, this.alpha + 0.02);
      if (this.alpha >= 1) {
        setTimeout(() => {
          this.fadeIn = false;
        }, 1000);
      }
    } else {
      this.alpha = Math.max(0, this.alpha - 0.02);
      if (this.alpha <= 0) {
        this.isComplete = true;
      }
    }
  }

  render() {
    this.ctx.save();
    
    // Dark background
    this.ctx.fillStyle = '#000';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Title text with blood drip effect
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    // Main title
    drawText(
      this.ctx,
      'ESCAPE',
      this.canvas.width / 2,
      this.canvas.height / 2 - 40,
      '72px',
      `rgba(255, 0, 0, ${this.alpha})`
    );
    
    drawText(
      this.ctx,
      'KELLAN\'S HOUSE',
      this.canvas.width / 2,
      this.canvas.height / 2 + 40,
      '48px',
      `rgba(255, 0, 0, ${this.alpha})`
    );
    
    // Blood drips
    this.drawBloodDrips();
    
    // Loading text
    this.ctx.font = '24px Arial';
    this.ctx.fillStyle = `rgba(255, 255, 255, ${this.alpha})`;
    this.ctx.fillText(
      'Loading...',
      this.canvas.width / 2,
      this.canvas.height - 100
    );
    
    this.ctx.restore();
  }

  drawBloodDrips() {
    const time = Date.now() / 1000;
    const drips = 8;
    
    for (let i = 0; i < drips; i++) {
      const x = this.canvas.width / 2 - 200 + (400 / drips) * i;
      const y = this.canvas.height / 2 - 20;
      const length = 20 + Math.sin(time + i) * 10;
      
      this.ctx.beginPath();
      this.ctx.moveTo(x, y);
      this.ctx.lineTo(x, y + length);
      this.ctx.strokeStyle = `rgba(255, 0, 0, ${this.alpha * 0.7})`;
      this.ctx.lineWidth = 3;
      this.ctx.stroke();
      
      // Drip drop
      this.ctx.beginPath();
      this.ctx.arc(x, y + length, 3, 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(255, 0, 0, ${this.alpha * 0.7})`;
      this.ctx.fill();
    }
  }
}