import { gameState } from './state.js';
import { audioManager } from './audio.js';
import { kellanAI } from './kellan.js';
import { DIFFICULTY_LEVELS } from './difficultyManager.js';
import { rooms } from '../config/rooms.js';

export class InputManager {
  constructor(canvas) {
    this.canvas = canvas;
    this.boundHandleKeyDown = this.handleKeyDown.bind(this);
    this.boundHandleMouseMove = this.handleMouseMove.bind(this);
    this.boundHandleTouchStart = this.handleTouchStart.bind(this);
    this.boundHandleTouchMove = this.handleTouchMove.bind(this);
    this.boundHandleTouchEnd = this.handleTouchEnd.bind(this);
    this.boundInitializeAudio = this.initializeAudio.bind(this);
    this.touchStartPos = null;
    this.isTouchMoving = false;
    this.virtualJoystickPos = { x: 0, y: 0 };
    this.lastTapTime = 0;
  }

  init() {
    document.addEventListener('keydown', this.boundHandleKeyDown);
    document.addEventListener('mousemove', this.boundHandleMouseMove);
    this.canvas.addEventListener('touchstart', this.boundHandleTouchStart);
    this.canvas.addEventListener('touchmove', this.boundHandleTouchMove);
    this.canvas.addEventListener('touchend', this.boundHandleTouchEnd);
    document.addEventListener('click', this.boundInitializeAudio, { once: true });
    document.addEventListener('touchstart', this.boundInitializeAudio, { once: true });
  }

  cleanup() {
    document.removeEventListener('keydown', this.boundHandleKeyDown);
    document.removeEventListener('mousemove', this.boundHandleMouseMove);
    this.canvas.removeEventListener('touchstart', this.boundHandleTouchStart);
    this.canvas.removeEventListener('touchmove', this.boundHandleTouchMove);
    this.canvas.removeEventListener('touchend', this.boundHandleTouchEnd);
  }

  handleTouchStart(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const touchPos = this.getTouchPos(touch);
    
    if (gameState.showDifficultySelect) {
      this.handleDifficultyTouchSelect(touchPos);
      return;
    }

    this.touchStartPos = touchPos;
    
    // Double tap to toggle lights
    const now = Date.now();
    if (this.lastTapTime && (now - this.lastTapTime) < 300) {
      gameState.lights = !gameState.lights;
    }
    this.lastTapTime = now;
  }

  handleTouchMove(e) {
    e.preventDefault();
    if (!this.touchStartPos || gameState.showDifficultySelect) return;

    const touch = e.touches[0];
    const currentPos = this.getTouchPos(touch);
    
    const dx = currentPos.x - this.touchStartPos.x;
    const dy = currentPos.y - this.touchStartPos.y;
    const distance = Math.hypot(dx, dy);
    
    if (distance > 10) {
      this.isTouchMoving = true;
      
      const speed = 5;
      const normalizedDx = dx / distance;
      const normalizedDy = dy / distance;
      
      gameState.playerPosition.x = Math.max(25, Math.min(this.canvas.width - 25,
        gameState.playerPosition.x + normalizedDx * speed));
      gameState.playerPosition.y = Math.max(25, Math.min(this.canvas.height - 25,
        gameState.playerPosition.y + normalizedDy * speed));
      
      if (!gameState.lights) {
        gameState.flashlightAngle = Math.atan2(dy, dx);
      }
      
      audioManager.play('footsteps');
    }
  }

  handleTouchEnd(e) {
    e.preventDefault();
    if (!this.isTouchMoving && this.touchStartPos) {
      // Check for interaction with nearby objects
      this.checkInteractions();
    }
    this.touchStartPos = null;
    this.isTouchMoving = false;
  }

  getTouchPos(touch) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    };
  }

  handleDifficultyTouchSelect(touchPos) {
    const difficulties = [
      { name: 'EASY', value: DIFFICULTY_LEVELS.EASY },
      { name: 'MEDIUM', value: DIFFICULTY_LEVELS.MEDIUM },
      { name: 'HARD', value: DIFFICULTY_LEVELS.HARD }
    ];

    const buttonHeight = 80;
    const startY = this.canvas.height / 2;

    difficulties.forEach((diff, index) => {
      const buttonY = startY + index * buttonHeight;
      if (touchPos.y >= buttonY - 30 && touchPos.y <= buttonY + 30) {
        gameState.difficulty = diff.value;
        setTimeout(() => {
          gameState.showDifficultySelect = false;
          kellanAI.updateDifficultySettings();
        }, 200);
      }
    });
  }

  handleKeyDown(e) {
    if (gameState.showDifficultySelect) {
      this.handleDifficultySelect(e);
      return;
    }

    if (gameState.isGameOver) {
      if (e.key.toLowerCase() === 'r') {
        this.restartGame();
      }
      return;
    }
    
    const speed = 5;
    let moved = false;
    
    switch(e.key) {
      case 'ArrowUp':
      case 'w':
        gameState.playerPosition.y = Math.max(25, gameState.playerPosition.y - speed);
        moved = true;
        break;
      case 'ArrowDown':
      case 's':
        gameState.playerPosition.y = Math.min(this.canvas.height - 25, gameState.playerPosition.y + speed);
        moved = true;
        break;
      case 'ArrowLeft':
      case 'a':
        gameState.playerPosition.x = Math.max(25, gameState.playerPosition.x - speed);
        moved = true;
        break;
      case 'ArrowRight':
      case 'd':
        gameState.playerPosition.x = Math.min(this.canvas.width - 25, gameState.playerPosition.x + speed);
        moved = true;
        break;
      case ' ':
        gameState.lights = !gameState.lights;
        break;
      case 'e':
        this.checkInteractions();
        break;
    }
    
    if (moved) {
      audioManager.play('footsteps');
    }
  }

  handleDifficultySelect(e) {
    switch(e.key) {
      case 'ArrowUp':
        gameState.difficulty = Math.max(0, gameState.difficulty - 1);
        break;
      case 'ArrowDown':
        gameState.difficulty = Math.min(2, gameState.difficulty + 1);
        break;
      case 'Enter':
        gameState.showDifficultySelect = false;
        kellanAI.updateDifficultySettings();
        break;
    }
  }

  handleMouseMove(e) {
    if (gameState.isGameOver || gameState.lights) return;
    
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    gameState.flashlightAngle = Math.atan2(
      y - gameState.playerPosition.y,
      x - gameState.playerPosition.x
    );
  }

  checkInteractions() {
    const currentRoom = rooms[gameState.currentRoom];
    const furniture = currentRoom.furniture;
    
    furniture.forEach(item => {
      if ((item.type === 'trapdoor' || item.isSecret) && this.isPlayerNear(item)) {
        if (item.leadsTo) {
          gameState.currentRoom = item.leadsTo;
          gameState.message = `You found a secret passage to the ${rooms[item.leadsTo].name}!`;
          setTimeout(() => {
            if (gameState.message.includes('secret passage')) {
              gameState.message = '';
            }
          }, 3000);
          audioManager.play('doorCreak');
        }
      }
    });
  }

  isPlayerNear(item) {
    const itemX = item.x * this.canvas.width;
    const itemY = item.y * this.canvas.height;
    const distance = Math.hypot(
      itemX - gameState.playerPosition.x,
      itemY - gameState.playerPosition.y
    );
    return distance < 50;
  }

  initializeAudio() {
    audioManager.init();
    audioManager.play('bgMusic');
    audioManager.play('heartbeat');
  }

  restartGame() {
    gameState.isGameOver = false;
    gameState.power = 100;
    gameState.time = 0;
    gameState.currentRoom = 'bedroom';
    gameState.kellanPosition = 'kitchen';
    gameState.lights = true;
    gameState.playerPosition = { 
      x: this.canvas.width / 2, 
      y: this.canvas.height / 2 
    };
    gameState.flashlightAngle = 0;
    gameState.shake = 0;
    gameState.vignette = 0;
    gameState.showDifficultySelect = true;
    
    kellanAI.position = {
      x: Math.random() * this.canvas.width,
      y: Math.random() * this.canvas.height
    };
  }
}