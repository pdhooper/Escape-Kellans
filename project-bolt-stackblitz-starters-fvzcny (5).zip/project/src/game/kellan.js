import { gameState } from './state.js';
import { rooms } from '../config/rooms.js';
import { audioManager } from './audio.js';
import { DifficultyManager, DIFFICULTY_LEVELS } from './difficultyManager.js';

class KellanAI {
  constructor() {
    this.difficultyManager = new DifficultyManager();
    this.lastMove = Date.now();
    this.moveInterval = 4000;
    this.huntMode = false;
    this.lastKnownPlayerRoom = null;
    this.speed = 3;
    this.position = { x: 0, y: 0 };
    this.chaseTimeout = null;
    this.lastKnownPositions = [];
    this.updateDifficultySettings();
  }

  updateDifficultySettings() {
    const settings = this.difficultyManager.getSettings(gameState.difficulty);
    this.speed = settings.kellanSpeed;
    this.moveInterval = settings.moveInterval;
    this.huntModeTime = settings.huntModeTime;
    this.predictionMultiplier = settings.predictionMultiplier;
  }

  update() {
    const now = Date.now();
    
    // Update hunt mode based on time and difficulty
    this.huntMode = gameState.time >= this.huntModeTime;
    
    // Track player's room
    if (this.lastKnownPlayerRoom !== gameState.currentRoom && !gameState.lights) {
      this.lastKnownPlayerRoom = gameState.currentRoom;
    }
    
    // Update position tracking
    this.lastKnownPositions.push({
      x: gameState.playerPosition.x,
      y: gameState.playerPosition.y,
      time: now
    });
    
    // Keep only last 5 seconds of positions
    this.lastKnownPositions = this.lastKnownPositions.filter(
      pos => now - pos.time < 5000
    );
    
    // Chase player if in same room
    if (gameState.currentRoom === gameState.kellanPosition) {
      this.chasePlayer();
    } else if (now - this.lastMove >= this.moveInterval) {
      this.moveToNewRoom();
      this.lastMove = now;
    }
    
    this.updateAudioEffects();
  }
  
  chasePlayer() {
    const dx = gameState.playerPosition.x - this.position.x;
    const dy = gameState.playerPosition.y - this.position.y;
    const distance = Math.hypot(dx, dy);
    
    if (distance > 10) {
      let predictedX = gameState.playerPosition.x;
      let predictedY = gameState.playerPosition.y;
      
      if (this.lastKnownPositions.length >= 2) {
        const latest = this.lastKnownPositions[this.lastKnownPositions.length - 1];
        const previous = this.lastKnownPositions[this.lastKnownPositions.length - 2];
        
        const moveX = latest.x - previous.x;
        const moveY = latest.y - previous.y;
        
        predictedX += moveX * this.predictionMultiplier;
        predictedY += moveY * this.predictionMultiplier;
      }
      
      const toPredictedX = predictedX - this.position.x;
      const toPredictedY = predictedY - this.position.y;
      const predictedDistance = Math.hypot(toPredictedX, toPredictedY);
      
      if (predictedDistance > 0) {
        const currentSpeed = this.huntMode ? this.speed * 1.2 : this.speed;
        this.position.x += (toPredictedX / predictedDistance) * currentSpeed;
        this.position.y += (toPredictedY / predictedDistance) * currentSpeed;
      }
      
      if (distance < 50) {
        this.catchPlayer();
      }
    }
  }

  catchPlayer() {
    if (!gameState.isGameOver) {
      gameState.isGameOver = true;
      audioManager.play('kellanScream');
      gameState.shake = 20;
    }
  }

  moveToNewRoom() {
    const currentRoom = rooms[gameState.kellanPosition];
    
    // Safety check to prevent errors if room is undefined
    if (!currentRoom || !currentRoom.connections) {
      // Reset to a known valid room if current position is invalid
      gameState.kellanPosition = 'hallway1';
      return;
    }
    
    let possibleRooms = currentRoom.connections;
    
    if (this.huntMode && this.lastKnownPlayerRoom) {
      const pathToPlayer = this.findPathToRoom(gameState.kellanPosition, this.lastKnownPlayerRoom);
      if (pathToPlayer.length > 1) {
        const nextRoom = pathToPlayer[1];
        if (rooms[nextRoom]) {  // Verify the room exists
          gameState.kellanPosition = nextRoom;
          this.position.x = Math.random() * window.innerWidth;
          this.position.y = Math.random() * window.innerHeight;
          audioManager.play('doorCreak');
          return;
        }
      }
    }
    
    // Filter out invalid rooms
    possibleRooms = possibleRooms.filter(room => rooms[room]);
    
    if (possibleRooms.length > 0) {
      const newRoom = possibleRooms[Math.floor(Math.random() * possibleRooms.length)];
      gameState.kellanPosition = newRoom;
      this.position.x = Math.random() * window.innerWidth;
      this.position.y = Math.random() * window.innerHeight;
      audioManager.play('doorCreak');
    }
  }

  findPathToRoom(start, end) {
    const visited = new Set();
    const queue = [[start]];
    
    while (queue.length > 0) {
      const path = queue.shift();
      const room = path[path.length - 1];
      
      if (room === end) {
        return path;
      }
      
      if (!visited.has(room) && rooms[room] && rooms[room].connections) {
        visited.add(room);
        const connections = rooms[room].connections;
        
        for (const nextRoom of connections) {
          if (!visited.has(nextRoom) && rooms[nextRoom]) {
            queue.push([...path, nextRoom]);
          }
        }
      }
    }
    
    return [start];
  }

  updateAudioEffects() {
    if (gameState.currentRoom === gameState.kellanPosition) {
      const distance = Math.hypot(
        this.position.x - gameState.playerPosition.x,
        this.position.y - gameState.playerPosition.y
      );
      
      // Update heartbeat volume based on proximity
      const heartbeatVolume = Math.min(0.8, (400 - distance) / 400);
      audioManager.setVolume('heartbeat', heartbeatVolume);
      
      // Play scream when very close
      if (distance < 100) {
        audioManager.play('kellanScream');
      }
    } else {
      audioManager.setVolume('heartbeat', 0);
    }
  }
}

export const kellanAI = new KellanAI();