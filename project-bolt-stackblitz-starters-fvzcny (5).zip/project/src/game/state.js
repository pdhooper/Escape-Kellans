export const gameState = {
  power: 100,
  time: 0,
  isGameOver: false,
  currentRoom: 'bedroom',
  kellanPosition: 'hallway1',
  lights: true,
  playerPosition: { x: 0, y: 0 },
  flashlightAngle: 0,
  ambientNoise: 0,
  shake: 0,
  vignette: 0,
  difficulty: 1,
  showDifficultySelect: true,
  message: '',
  showKeypad: false,
  keypadInput: '',
  inventory: new Set()
};