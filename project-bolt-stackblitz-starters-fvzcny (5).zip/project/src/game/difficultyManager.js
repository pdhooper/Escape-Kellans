export const DIFFICULTY_LEVELS = {
  EASY: 0,
  MEDIUM: 1,
  HARD: 2
};

export class DifficultyManager {
  constructor() {
    this.settings = {
      [DIFFICULTY_LEVELS.EASY]: {
        kellanSpeed: 2,
        moveInterval: 6000,
        huntModeTime: 240, // 4 AM
        powerDrain: 0.5,
        predictionMultiplier: 1.0
      },
      [DIFFICULTY_LEVELS.MEDIUM]: {
        kellanSpeed: 3,
        moveInterval: 4000,
        huntModeTime: 180, // 3 AM
        powerDrain: 1.0,
        predictionMultiplier: 1.2
      },
      [DIFFICULTY_LEVELS.HARD]: {
        kellanSpeed: 4,
        moveInterval: 3000,
        huntModeTime: 120, // 2 AM
        powerDrain: 1.5,
        predictionMultiplier: 1.5
      }
    };
  }

  getSettings(difficulty) {
    return this.settings[difficulty];
  }
}